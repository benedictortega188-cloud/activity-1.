# DEBESMSCAT Website

A responsive, multi-page campus showcase website made with **HTML5 and CSS3 only**.

## Pages
- `index.html` — Home page
- `about.html` — About page
- `gallery.html` — Photo gallery

## Folder structure
```text
debesmscat_website/
├── index.html
├── about.html
├── gallery.html
├── css/
│   └── style.css
├── images/
│   ├── campus-hero.jpg
│   └── website-design-preview.jpg
└── README.md
```

## Run locally
Open `index.html` in a web browser. An internet connection is needed for the sample gallery photos and Google Fonts.

## Publish with GitHub Pages
1. Create a **public** GitHub repository.
2. Upload all files and folders from this project.
3. Open the repository's **Settings → Pages**.
4. Under Build and deployment, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)` folder, then save.
6. Wait for GitHub Pages to publish the site. Open the URL shown in the Pages section.

## Activity requirement
The project uses HTML and CSS only. It does not include JavaScript or JavaScript libraries.

## Before submitting
Replace sample gallery images with your own campus photos if required by your instructor. Check every page and link after publishing.
